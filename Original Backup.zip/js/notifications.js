/*generateNotification();
generateNotification();
generateNotification();

sendNotification(type,tag) {

}

generateNotification(){
titles.push('Notification Title');
bodies.push('Notif Body');
timeouts.push(int('4000'));
isSilent.push(true);
opensWindow.push(true);
closesNotification.push(true);
type.push('Encourage');
console.log(titles);
console.log(bodies);
}

evalNotification(){

}

onClick(){

}

var titles = [];
var bodies = [];
var timeouts = [];
var isSilent = [];
var opensWindow = [];
var closesNotification = [];
var type = [];

var titlesList = [];
var bodiesList = [];
*/
